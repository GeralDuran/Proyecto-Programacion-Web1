<?php
$host = '127.0.0.1:3306';
$user = 'root';
$pass = 'Evelin58GD051005';
$db = 'login_db';


$conn = new mysqli($host,$user,$pass,$db);

// Conexión al login
$connLogin = new mysqli($host, $user, $pass, 'login_db');
if($connLogin->connect_error) die("Error login DB: ".$connLogin->connect_error);

// Conexión al CRUD
$connCRUD = new mysqli($host, $user, $pass, 'crud_app');
if($connCRUD->connect_error) die("Error CRUD DB: ".$connCRUD->connect_error");

?>