<?php
$host = '127.0.0.1:3306';
$user = 'root';
$pass = 'Evelin58GD051005';
$db = 'crud_app';


$conn = new mysqli($host,$user,$pass,$db);

if($conn->connect_error){
    die('Error en la conexion de mi db: ' . $conn->connect_error);
}
?>
