<?php
session_start();

// Conexión a login_db
$host = '127.0.0.1:3306';
$user = 'root';
$pass = 'Evelin58GD051005';
$db = 'login_db';

$conn = new mysqli($host, $user, $pass, $db);
if($conn->connect_error){
    die('Error en la conexión a login_db: ' . $conn->connect_error);
}

$usuario = $_POST['nombre_usuario'];
$password = $_POST['password'];

$q = "SELECT COUNT(*) as contar FROM users WHERE username='$usuario' AND password='$password'";
$consulta = mysqli_query($conn, $q);
$array = mysqli_fetch_array($consulta);

if($array['contar'] > 0){
    $_SESSION['username'] = $usuario;
    header("Location: ../paginaPrincipal.php");
    exit();
} else {
    header("Location: ../index.php");
    exit();
}
?>
