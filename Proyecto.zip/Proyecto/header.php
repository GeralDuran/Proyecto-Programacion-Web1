<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Registro</title>

    <!-- Material Icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <!-- Materialize CSS LOCAL -->
    <link rel="stylesheet" href="css/materialize.min.css">

    <!-- CSS -->
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body class="container">

    <!-- Navbar -->
    <nav>
        <div class="nav-wrapper blue darken-2">
            <a href="paginaPrincipal.php" class="brand-logo center">Registro de Usuarios</a>
        </div>
    </nav>
    <br>
