    <!-- Footer -->
<footer class="page-footer blue darken-2" style="margin-top: 20px; padding: 15px 0;">
    <div class="container center white-text">
        © 2025 Mi página web
    </div>
</footer>

<!-- jQuery -->
<script src="js/jquery-3.7.1.min.js"></script>

<!-- Materialize JS -->
<script src="js/materialize.min.js"></script>

<!-- JS personalizado -->
<script src="js/app.js"></script>
</body>
</html>
