<?php
include("header.php");
include("logica/db.php");

if (isset($_POST['agregar'])) {
    $nombre   = $_POST['nombre'];
    $email    = $_POST['email'];
    $telefono = $_POST['telefono'];

    $sql = "INSERT INTO usuarios (nombre, email, telefono) VALUES ('$nombre','$email','$telefono')";

    if ($conn->query($sql) === TRUE) {
        header("Location: paginaPrincipal.php");
        exit();
    } else {
        echo "<p class='red-text'>Error al guardar: " . $conn->error . "</p>";
    }
}
?>

<h3>Agregar Nuevo Usuario</h3>

<form action="" method="POST">
    <div class="input-field">
        <input type="text" name="nombre" id="nombre" required>
        <label for="nombre">Nombre</label>
    </div>
    <div class="input-field">
        <input type="email" name="email" id="email" required>
        <label for="email">Email</label>
    </div>
    <div class="input-field">
        <input type="text" name="telefono" id="telefono" required>
        <label for="telefono">Teléfono</label>
    </div>

    <button type="submit" name="agregar" class="btn blue waves-effect waves-light">
        <i class="material-icons left">person_add</i> Agregar
    </button>

    <button type="button" class="btn grey waves-effect waves-light" onclick="window.location.href='paginaPrincipal.php'">
        Cancelar
    </button>
</form>

<?php include("footer.php"); ?>
