<?php include("header.php"); ?>

<div class="row">
    <div class="col s12 m6 offset-m3">
        <div class="card">
            <div class="card-content">
                <span class="card-title center">Iniciar Sesión</span>

                <form action="logica/validarLogin.php" method="POST">

                    <div class="input-field">
                        <input type="text" name="nombre_usuario" id="usuario" required>
                        <label for="usuario">Nombre de Usuario</label>
                    </div>

                    <div class="input-field">
                        <input type="password" name="password" id="password" required>
                        <label for="password">Contraseña</label>
                    </div>

                    <button class="btn blue darken-3 waves-effect waves-light" 
                            type="submit">
                        Entrar
                    </button>

                </form>
            </div>
        </div>
    </div>
</div>

<?php include("footer.php"); ?>
