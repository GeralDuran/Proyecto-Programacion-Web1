<?php
include("header.php");
include("logica/db.php");

// Guardar edición inline
if(isset($_POST['guardar'])){
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $telefono = $_POST['telefono'];

    $conn->query("UPDATE usuarios SET nombre='$nombre', email='$email', telefono='$telefono' WHERE id=$id");
    header("Location: paginaPrincipal.php");
    exit();
}

// Eliminar usuario
if(isset($_GET['eliminar'])){
    $id = $_GET['eliminar'];
    $conn->query("DELETE FROM usuarios WHERE id=$id");
    header("Location: paginaPrincipal.php");
    exit();
}
?>

<h3>Listado de Usuarios</h3>

<!-- Botón agregar usuario -->
<a class="btn blue waves-effect waves-light" href="registro.php">
    <i class="material-icons left">person_add</i> Agregar Usuario
</a>

<br><br>

<table class="highlight responsive-table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Email</th>
            <th>Teléfono</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
    <?php
    $result = $conn->query("SELECT * FROM usuarios");
    while($row = $result->fetch_assoc()):
    ?>
        <tr>
        <form method="POST">
            <td><?php echo $row['id']; ?></td>
            <td><input type="text" name="nombre" value="<?php echo $row['nombre']; ?>" readonly data-default="<?php echo $row['nombre']; ?>"></td>
            <td><input type="email" name="email" value="<?php echo $row['email']; ?>" readonly data-default="<?php echo $row['email']; ?>"></td>
            <td><input type="text" name="telefono" value="<?php echo $row['telefono']; ?>" readonly data-default="<?php echo $row['telefono']; ?>"></td>
            <td>
                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">

                <button type="button" class="btn orange editar">Editar</button>
                <button type="submit" name="guardar" class="btn green guardar" style="display:none;">Guardar</button>
                <button type="button" class="btn grey cancelar" style="display:none;">Cancelar</button>
                <button type="button" class="btn red eliminar" onclick="if(confirm('¿Está seguro de eliminar?')) window.location='?eliminar=<?php echo $row['id']; ?>';">Eliminar</button>
            </td>
        </form>
        </tr>
    <?php endwhile; ?>
    </tbody>
</table>

<script>
// Activar edición
document.querySelectorAll('.editar').forEach(function(btn){
    btn.addEventListener('click', function(){
        let fila = btn.closest('tr');
        fila.querySelectorAll('input[type=text], input[type=email]').forEach(input => input.removeAttribute('readonly'));
        btn.style.display = 'none';
        fila.querySelector('.guardar').style.display = 'inline-block';
        fila.querySelector('.cancelar').style.display = 'inline-block';
    });
});

// Cancelar edición
document.querySelectorAll('.cancelar').forEach(function(btn){
    btn.addEventListener('click', function(){
        let fila = btn.closest('tr');
        fila.querySelectorAll('input[type=text], input[type=email]').forEach(input => {
            input.setAttribute('readonly', true);
            input.value = input.dataset.default;
        });
        fila.querySelector('.editar').style.display = 'inline-block';
        fila.querySelector('.guardar').style.display = 'none';
        fila.querySelector('.cancelar').style.display = 'none';
    });
});
</script>

<?php include("footer.php"); ?>
